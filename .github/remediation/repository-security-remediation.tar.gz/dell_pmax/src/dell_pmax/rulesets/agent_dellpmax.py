"""Ruleset for the Dell EMC PowerMax special agent."""

from cmk.rulesets.v1 import Help, Title
from cmk.rulesets.v1.form_specs import (
    DefaultValue,
    DictElement,
    Dictionary,
    Integer,
    Password,
    String,
    TimeMagnitude,
    TimeSpan,
)
from cmk.rulesets.v1.form_specs.validators import LengthInRange
from cmk.rulesets.v1.rule_specs import SpecialAgent, Topic


def _parameter_form_dell_powermax() -> Dictionary:
    return Dictionary(
        title=Title("Check state of Dell EMC PowerMax storage pools"),
        help_text=Help(
            "Monitors Dell EMC PowerMax through the Unisphere REST API. Use a "
            "read-only monitoring account and trusted HTTPS certificates."
        ),
        elements={
            "username": DictElement(
                required=True,
                parameter_form=String(
                    title=Title("Username"),
                    help_text=Help("Read-only monitoring account."),
                    custom_validate=(LengthInRange(min_value=1),),
                ),
            ),
            "password": DictElement(
                required=True,
                parameter_form=Password(title=Title("Password")),
            ),
            "port": DictElement(
                required=True,
                parameter_form=Integer(
                    title=Title("HTTPS port"),
                    prefill=DefaultValue(8443),
                ),
            ),
            "api_version": DictElement(
                required=True,
                parameter_form=Integer(
                    title=Title("Unisphere API version"),
                    prefill=DefaultValue(92),
                ),
            ),
            "timeout": DictElement(
                required=True,
                parameter_form=TimeSpan(
                    title=Title("Request timeout"),
                    displayed_magnitudes=(TimeMagnitude.SECOND,),
                    prefill=DefaultValue(15.0),
                ),
            ),
            "ca_bundle": DictElement(
                required=False,
                parameter_form=String(
                    title=Title("Private CA bundle"),
                    help_text=Help(
                        "Optional absolute path to a PEM CA bundle on the Checkmk site. "
                        "Leave empty to use the system trust store."
                    ),
                ),
            ),
        },
    )


rule_spec_dellpmax_agent = SpecialAgent(
    name="dellpmax",
    topic=Topic.STORAGE,
    parameter_form=_parameter_form_dell_powermax,
    title=Title("Dell PowerMax"),
)
